x=input("Masukkan DNA sequence: ").upper()
total=len(x)
c=x.count("C")
g=x.count("G")

gc_total=g+c
gc_content=gc_total
print(gc_content)