# -*- coding: utf-8 -*-
"""
Created on Wed Sep 12 13:29:36 2018

@author: HNAF
"""

a=5
b=4
c=5

d=(a*b*c)
print("d=a*b*c")
print(d)